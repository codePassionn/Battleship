﻿using System;
using System.Collections;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Text.RegularExpressions;
using System.Security.Cryptography;

namespace BattleShipClient
{
    public class SslTcpClient
    {
        private Hashtable certificateErrors = new Hashtable();
        private SslStream sslStream;
        // The following method is invoked by the RemoteCertificateValidationDelegate.
        public static bool ValidateServerCertificate(
              object sender,
              X509Certificate certificate,
              X509Chain chain,
              SslPolicyErrors sslPolicyErrors)
        {
            if (sslPolicyErrors == SslPolicyErrors.None)
                return true;

            Console.WriteLine("Certificate error: {0}", sslPolicyErrors);

            // Do not allow this client to communicate with unauthenticated servers.
            return false;
        }

        public void RunClient(string machineName, string serverName)
        {
            AppDomain domain = AppDomain.CurrentDomain;
            // Set a timeout interval of 2 seconds.
            domain.SetData("REGEX_DEFAULT_MATCH_TIMEOUT", TimeSpan.FromSeconds(10));

            // Create a TCP/IP client socket.
            // machineName is the host running the server application.
            TcpClient client = new TcpClient(machineName, 7777);
            Console.WriteLine("Client connected.");
            // Create an SSL stream that will close the client's stream.
            sslStream = new SslStream(
                client.GetStream(),
                false,
                new RemoteCertificateValidationCallback(ValidateServerCertificate),
                null
                );
            // The server name must match the name on the server certificate.
            try
            {
                sslStream.AuthenticateAsClient(serverName);// "AMYN-PC\\Amyn");
            }
            catch (AuthenticationException e)
            {
                //Console.WriteLine("Exception: {0}", e.Message);
                if (e.InnerException != null)
                {
                    //Console.WriteLine("Inner exception: {0}", e.InnerException.Message);
                }
                Console.WriteLine("Authentication failed - closing the connection.");
                client.Close();
                return;
            }
            LoginRegisterMenu();

            client.Close();
            Console.WriteLine("Client closed.");
        }

        private void LoginRegisterMenu()
        {
            bool isLoginRegisterMenu = true;
            while (isLoginRegisterMenu)
            {
                Console.WriteLine("Select an option:");
                Console.WriteLine("1. Register");
                Console.WriteLine("2. Login");
                Console.WriteLine("3. Quit");
                try
                {
                    short option = Convert.ToInt16(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                            createNewAccount();
                            //isLoginRegisterMenu = false;
                            break;
                        case 2:
                            loginUser();
                            break;
                        case 3:
                            sslStream.Write(Encoding.UTF8.GetBytes("Quit<EOF>"));
                            isLoginRegisterMenu = false;
                            break;
                        default:
                            Console.WriteLine("Invalid option selected.\n");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Invalid option selected.\n");
                }
            }
        }

        private void loginUser()
        {
            bool isValid = false;
            while (!isValid)
            {
                Console.Write("Username: ");
                string username = Console.ReadLine();
                Console.Write("Password: ");
                string password = readPassword();
                if (validateUsername(username) && isStrongPassword(password))
                {
                    isValid = LoginUser(username, password);
                    if (isValid)
                    {
                        runGame();
                    }
                    else
                    {
                        Console.WriteLine("Error: Invalid username and/or password.");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Username and/or password does not fullfill the requirements.");
                }
            }
        }

        // Source: http://stackoverflow.com/questions/3404421/password-masking-console-application?lq=1
        private string readPassword()
        {
            string pass = "";
            ConsoleKeyInfo key;
            do
            {
                key = Console.ReadKey(true);

                // Backspace Should Not Work
                if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                {
                    pass += key.KeyChar;
                    Console.Write("*");
                }
                else
                {
                    if (key.Key == ConsoleKey.Backspace && pass.Length > 0)
                    {
                        pass = pass.Substring(0, (pass.Length - 1));
                        Console.Write("\b \b");
                    }
                }
            }
            // Stops Receving Keys Once Enter is Pressed
            while (key.Key != ConsoleKey.Enter);
            Console.WriteLine();
            return pass;
        }

        private void runGame()
        {
            bool runningGame = true;
            while (runningGame)
            {
                Console.WriteLine("1. Create a new game.");
                Console.WriteLine("2. Join a game.");
                Console.WriteLine("3. Show stats.");
                Console.WriteLine("4. Logout.");

                try
                {
                    short option = Convert.ToInt16(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                            createNewGame();
                            break;
                        case 2:
                            joinGame();
                            break;
                        case 3:
                            sslStream.Write(Encoding.UTF8.GetBytes("Stats<EOF>"));
                            string serverResponse = ReadMessage(sslStream).Replace("<EOF>","");
                            Console.WriteLine(serverResponse);
                            break;
                        case 4:
                            sslStream.Write(Encoding.UTF8.GetBytes("Logout<EOF>"));
                            Console.WriteLine("Logged out.\n");
                            runningGame = false;
                            break;
                        default:
                            Console.WriteLine("Invalid option selected.\n");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    runningGame = false;
                    Console.WriteLine("Invalid option selected.\n");
                }
            }
        }

        private void joinGame()
        {
            sslStream.Write(Encoding.UTF8.GetBytes("Join<EOF>"));
            string serverResponse = ReadMessage(sslStream);
            string[] serverReply = serverResponse.Replace("<EOF>", "").Split(',');
            switch (serverReply[0])
            {
                case "Info":
                    Console.WriteLine("Info: " + serverReply[1]);
                    break;
                case "Begin":
                    {
                        Console.WriteLine("Begin: ");
                        gameMode();
                    }
                    break;
                case "Error":
                    Console.WriteLine("Error: " + serverReply[1]);
                    break;
                default:
                    Console.WriteLine("Default: " + serverResponse);
                    break;
            }
        }

        private void createNewGame()
        {
            sslStream.Write(Encoding.UTF8.GetBytes("New<EOF>"));
            bool isPlaying = true;
            while (isPlaying)
            {
                string serverResponse = ReadMessage(sslStream);
                string[] serverReply = serverResponse.Replace("<EOF>", "").Split(',');
                switch (serverReply[0])
                {
                    case "Info":
                        Console.WriteLine("Info: " + serverReply[1]);
                        break;
                    case "Begin":
                        {
                            Console.WriteLine("Begin: ");
                            gameMode();
                            isPlaying = false;
                        }
                        break;
                    case "Error":
                        Console.WriteLine("Error: " + serverReply[1]);
                        break;
                    default:
                        Console.WriteLine("Default: " + serverReply[1]);
                        break;
                }
            }
        }

        private bool sendMessage(string message)
        {
            try
            {
                sslStream.Write(Encoding.UTF8.GetBytes(message + "<EOF>"));
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        private void gameMode()
        {
            bool isGaming = true;
            while (isGaming)
            {
                string serverResponse = ReadMessage(sslStream);
                string[] serverReply = serverResponse.Replace("<EOF>", "").Split(',');
                switch (serverReply[0])
                {
                    case "Info":
                        Console.WriteLine("Info: " + serverReply[1]);
                        break;
                    case "Read":
                        Console.WriteLine("Read: " + serverReply[1]);
                        string userInput = Console.ReadLine();
                        sendMessage(userInput);
                        break;
                    case "Write":    
                        Console.WriteLine("Write: " + serverReply[1]);
                        break;
                    case "Error":
                        Console.WriteLine("Error: " + serverReply[1]);
                        break;
                    case "GameOver":
                        Console.WriteLine("Game Over.");
                        isGaming = false;
                        break;
                    default:
                        Console.WriteLine("Default: " + serverReply[1]);
                        break;
                }
            }
        }

        private bool LoginUser(string username, string password)
        {
            if (sslStream == null)
            {
                Console.WriteLine("Connection to the server is lost. Please re run the program.");
                return false;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append("Login<EOF>");
            sslStream.Write(Encoding.UTF8.GetBytes((sb.ToString())));
            sslStream.Flush();

            sb.Clear();
            sb.Append(username);
            sb.Append("<EOF>");
            sslStream.Write(Encoding.UTF8.GetBytes((sb.ToString())));
            sslStream.Flush();

            sb.Clear();
            sb.Append(password);
            sb.Append("<EOF>");
            sslStream.Write(Encoding.UTF8.GetBytes((sb.ToString())));
            sslStream.Flush();

            string serverMessage = ReadMessage(sslStream);
            if (string.IsNullOrEmpty(serverMessage))
            {
                Console.WriteLine("No response from server. Please try again later.");
                return false;
            }
            string[] serverResponse = serverMessage.Split(',');
            if (serverResponse[0].Equals("Error"))
            {
                Console.WriteLine("Error: " + serverResponse[1].Substring(0, serverResponse[1].IndexOf("<EOF>")));
                return false;
            }
            if (serverResponse[0].Equals("Success"))
            {
                Console.WriteLine("Login successful.");
                return true;
            }
            Console.WriteLine("Login failed.");
            return false;
        }

        string ReadMessage(SslStream sslStream)
        {
            // Read the  message sent by the server.
            // The end of the message is signaled using the
            // "<EOF>" marker.
            byte[] buffer = new byte[2048];
            StringBuilder messageData = new StringBuilder();
            int bytes = -1;
            do
            {
                bytes = sslStream.Read(buffer, 0, buffer.Length);

                // Use Decoder class to convert from bytes to UTF8
                // in case a character spans two buffers.
                Decoder decoder = Encoding.UTF8.GetDecoder();
                char[] chars = new char[decoder.GetCharCount(buffer, 0, bytes)];
                decoder.GetChars(buffer, 0, bytes, chars, 0);
                messageData.Append(chars);
                // Check for EOF.
                if (messageData.ToString().IndexOf("<EOF>") != -1)
                {
                    break;
                }
            } while (bytes != 0);

            return messageData.ToString();
        }

        private void DisplayUsage()
        {
            Console.WriteLine("To start the client specify:");
            Console.WriteLine("clientSync machineName [serverName]");
            Environment.Exit(1);
        }

        public int startClient(string[] args)
        {
            string serverCertificateName = null;
            string machineName = null;
            if (args == null || args.Length < 1)
            {
                DisplayUsage();
            }
            // User can specify the machine name and server name.
            // Server name must match the name on the server's certificate. 
            machineName = args[0];
            if (args.Length < 2)
            {
                serverCertificateName = machineName;
            }
            else
            {
                serverCertificateName = args[1];
            }
            RunClient(machineName, serverCertificateName);
            return 0;
        }
        
        private void createNewAccount()
        {
            bool isValid = false;
            while (!isValid)
            {
                Console.Write("Enter your desierd username: ");
                string username = Console.ReadLine();
                Console.WriteLine("\nPassword rules:");
                Console.WriteLine("1. Length 8 - 15");
                Console.WriteLine("2. Atleast 2 characters");
                Console.WriteLine("3. Atleast 1 numeric value");
                Console.WriteLine("4. Atleast 1 special character");
                Console.WriteLine("5. No spaces\n");
                Console.Write("Enter your desired password(Length:): ");
                string password = readPassword();
                if (isStrongPassword(password))
                {
                    isValid = RegisterUser(username, password);
                }
            }
        }

        private bool RegisterUser(string username, string password)
        {
            if (sslStream == null) {
                Console.WriteLine("Connection to the server is lost. Please re run the program.");
                return false; 
            }

            StringBuilder sb = new StringBuilder();
            sb.Append("Register<EOF>");
            sslStream.Write(Encoding.UTF8.GetBytes((sb.ToString())));
            sslStream.Flush();

            sb.Clear();
            sb.Append(username);
            sb.Append("<EOF>");
            sslStream.Write(Encoding.UTF8.GetBytes((sb.ToString())));
            sslStream.Flush();

            sb.Clear();
            sb.Append(password);
            sb.Append("<EOF>");
            sslStream.Write(Encoding.UTF8.GetBytes((sb.ToString())));
            sslStream.Flush();

            string serverMessage = ReadMessage(sslStream);
            if (string.IsNullOrEmpty(serverMessage)) {
                Console.WriteLine("No response from server. Please try again later.");
                return false; 
            }
            string[] serverResponse = serverMessage.Split(',');
            if (serverResponse[0].Equals("Error"))
            {
                Console.WriteLine("Error: " + serverResponse[1].Substring(0, serverResponse[1].IndexOf("<EOF>")));
                return false;
            }
            if (serverResponse[0].Equals("Success"))
            {
                Console.WriteLine("Registration successful.");
                return true;
            }
            Console.WriteLine("Registration failed.");
            return false;
        }

        // Source: http://regexlib.com/REDetails.aspx?regexp_id=2799
        private bool isStrongPassword(string password)
        {
            return Regex.IsMatch(password, @"^(?=(.*[a-zA-Z].*){2,})(?=.*\d.*)(?=.*\W.*)[a-zA-Z0-9\S]{8,15}$");
        }

        private string computeHash(string value)
        {
            System.Security.Cryptography.SHA256Managed crypt = new System.Security.Cryptography.SHA256Managed();
            System.Text.StringBuilder hash = new System.Text.StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(value), 0, Encoding.UTF8.GetByteCount(value));
            foreach (byte theByte in crypto)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }

        private bool validateUsername(string username)
        {
            string pattern = @"^[A-Za-z]{8,15}$";
            return Regex.IsMatch(username, pattern);
        }
    }
}