﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BattleShipClient
{
    class Program
    {
        static void Main(string[] args)
        {
            SslTcpClient newClient = new SslTcpClient();
            newClient.startClient(args);
        }
    }
}
