USE [Blackship]
GO

/****** Object:  Table [dbo].[players]    Script Date: 5/4/2016 11:13:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[players](
	[player_id] [bigint] IDENTITY(1,1) NOT NULL,
	[player_username] [nvarchar](50) NOT NULL,
	[player_password] [nvarchar](256) NOT NULL,
	[player_salt] [nvarchar](256) NOT NULL,
	[iteration_count] [int] NOT NULL,
 CONSTRAINT [PK_players] PRIMARY KEY CLUSTERED 
(
	[player_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


