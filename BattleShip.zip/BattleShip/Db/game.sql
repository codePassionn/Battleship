USE [Blackship]
GO

/****** Object:  Table [dbo].[game]    Script Date: 5/4/2016 11:12:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[game](
	[game_id] [bigint] IDENTITY(1,1) NOT NULL,
	[player1_id] [bigint] NOT NULL,
	[player2_id] [bigint] NOT NULL,
	[player1win] [bit] NOT NULL,
	[player2win] [bit] NOT NULL,
	[draw] [bit] NOT NULL,
 CONSTRAINT [PK_game] PRIMARY KEY CLUSTERED 
(
	[game_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[game]  WITH CHECK ADD  CONSTRAINT [FK_game_players1] FOREIGN KEY([player1_id])
REFERENCES [dbo].[players] ([player_id])
GO

ALTER TABLE [dbo].[game] CHECK CONSTRAINT [FK_game_players1]
GO

ALTER TABLE [dbo].[game]  WITH CHECK ADD  CONSTRAINT [FK_game_players2] FOREIGN KEY([player2_id])
REFERENCES [dbo].[players] ([player_id])
GO

ALTER TABLE [dbo].[game] CHECK CONSTRAINT [FK_game_players2]
GO


