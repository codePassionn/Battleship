﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace BattleShip
{
    class Program
    {
        static String[,] p1Board = new String[10, 10];
        static String[,] p2Board = new String[10, 10];

        static String[,] p2Hit = new String[10, 10];// the performance of player 2
        static String[,] p1Hit = new String[10, 10]; // the performance of player 1 

        //p2Board = ship location record for player 2. same for player 1
        //p2 hit = where the player is aiming respectively to hit the opposite board. 

        static int hitCounterp1 = 0;
        static int hitCounterp2 = 0;

        static Boolean hasWon = false;

        static void initilizeVariables()
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    p1Board[i, j] = " ";
                    p2Board[i, j] = " ";
                    p1Hit[i, j] = " ";
                    p2Hit[i, j] = " ";
                }
            }
        }

        //static void Main(string[] args)
        //{

        //    // showBoard("P1");
        //    initilizeVariables();

        //    helloPlayers();
        //    queryInputData();
        //    seeYouPlayers();
        //}
        static void seeYouPlayers()
        {
            Console.Clear();
            Console.WriteLine("Thank you for playing Battleship!");
            Console.WriteLine("The winner is :");
            if (hitCounterp1 == 17)
                Console.WriteLine("Player 1!");
            else
                Console.WriteLine("Player 2!");
            Console.WriteLine("Thank you for playing.");
            Console.ReadLine();
        }


        //----------Initilization and input deploit for 2 players. 
        static void inputShipLocation()
        {
            Console.Clear();
            Console.WriteLine("This is the turn for Player 1!  Player 2: Leave!");
            Console.ReadLine();
            Console.Clear();
            int rowN = 0;
            int colN = 0;
            string selection;
            const string errMSG = "Invalid Input, Please input in the format of two character string, the first character is from A to J, the second is from 0 to 9!!!";


            //-----------------------------------------------
            Console.WriteLine("Please select the location of your ship patrol based on the graph");
            showBoard("P1");
            selection = Console.ReadLine();

            while (!inputValidation(selection, 2)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to I, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }

            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p1Board[rowN, colN] = "S";
            p1Board[rowN + 1, colN] = "S";
            //------------------------------------------------------------------------------------------------------------
            Console.WriteLine("Please select the location of your Destroyer ship  based on the graph");
            showBoard("P1");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 3)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to H, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p1Board[rowN, colN] = "S";
            p1Board[rowN + 1, colN] = "S";
            p1Board[rowN + 2, colN] = "S";

            //--------------------------
            Console.WriteLine("Please select the location of your Submarine ship based on the graph");
            showBoard("P1");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 3)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to H, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p1Board[rowN, colN] = "S";
            p1Board[rowN + 1, colN] = "S";
            p1Board[rowN + 2, colN] = "S";

            //--------------------------
            Console.WriteLine("Please select the location of your BattleShip ship based on the graph");
            showBoard("P1");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 4)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to G, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p1Board[rowN, colN] = "S";
            p1Board[rowN + 1, colN] = "S";
            p1Board[rowN + 2, colN] = "S";
            p1Board[rowN + 3, colN] = "S";
            //---------------------------------------------------
            Console.WriteLine("Please select the location of your Carrier ship based on the graph");
            showBoard("P1");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 5)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to F, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p1Board[rowN, colN] = "S";
            p1Board[rowN + 1, colN] = "S";
            p1Board[rowN + 2, colN] = "S";
            p1Board[rowN + 3, colN] = "S";
            p1Board[rowN + 4, colN] = "S";

            //---------------------Initilization for Player 2
            //-------------------------------------------------------
            Console.Clear();
            Console.WriteLine("Player 2! it is your turn! Press any key to continue.");
            Console.ReadLine();

            Console.WriteLine("Please select the location of your Patrol ship bsed on the graph");
            showBoard("P2");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 2)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to I, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;

            p2Board[rowN, colN] = "S";
            p2Board[rowN + 1, colN] = "S";
            //-----------------------------------------------------
            Console.WriteLine("Please select the location of your Destroyer ship based on the graph");
            showBoard("P2");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 3)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to H, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p2Board[rowN, colN] = "S";
            p2Board[rowN + 1, colN] = "S";
            p2Board[rowN + 2, colN] = "S";

            //---------------------------------------------------
            Console.WriteLine("Please select the location of your Submarine ship based on the graph");
            showBoard("P2");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 3)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to H, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p2Board[rowN, colN] = "S";
            p2Board[rowN + 1, colN] = "S";
            p2Board[rowN + 2, colN] = "S";

            //---------------------------------------------------
            Console.WriteLine("Please select the location of your BattleShip ship based on the graph");
            showBoard("P2");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 4)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to G, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p2Board[rowN, colN] = "S";
            p2Board[rowN + 1, colN] = "S";
            p2Board[rowN + 2, colN] = "S";
            p2Board[rowN + 3, colN] = "S";

            //------------------------------------------------------------

            Console.WriteLine("Please select the location of your Carrier ship based on the graph");
            showBoard("P2");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 5)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to F, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            p2Board[rowN, colN] = "S";
            p2Board[rowN + 1, colN] = "S";
            p2Board[rowN + 2, colN] = "S";
            p2Board[rowN + 3, colN] = "S";
            p1Board[rowN + 4, colN] = "S";





        }

        static void playHitGames()
        {
            Console.Clear();
            string selection;
            int rowN = 0;
            int colN = 0;
            //-----------------------------
            Console.WriteLine("Player 1: please enter your seledtion based on the previous hit choice.");
            showBoard("P1Hit");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 1)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to J, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            if (p2Board[rowN, colN] != " " && p1Hit[rowN, colN] != "H")
            {
                Console.WriteLine("HIT!");
                p1Hit[rowN, colN] = "H";
                hitCounterp1++;
                if (hitCounterp1 == 17)
                    hasWon = true;
            }
            else
            {
                Console.WriteLine("MISS!");
                p1Hit[rowN, colN] = "M";
            }
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Player 2: please enter your selection based on the previous hit choice.");
            showBoard("P2Hit");
            selection = Console.ReadLine();
            while (!inputValidation(selection, 1)) //-input validation process 
            {
                Console.WriteLine("Invalid Input, Please input in the format of two character string, the first character is from A to J, the second is from 0 to 9!!");
                selection = Console.ReadLine();
            }
            rowN = Convert.ToInt32(selection[0]) - 65;
            colN = Convert.ToInt32(selection[1]) - 48;
            if (p1Board[rowN, colN] != " " && p2Hit[rowN, colN] != "H")
            {
                Console.WriteLine("HIT!");
                p2Hit[rowN, colN] = "H";
                hitCounterp2++;
                if (hitCounterp2 == 17)
                    hasWon = true;
            }
            else
            {
                Console.WriteLine("MISS!");
                p2Hit[rowN, colN] = "M";
            }
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadLine();
        }

        static void queryInputData()
        {
            inputShipLocation();
            while (!hasWon)
            {
                playHitGames();
            }

        }
        static void showBoard(String selection)
        {
            if (selection.Equals("P1"))
            {
                for (int x = 0; x < 10; x++)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        Console.Write(p1Board[x, i] + "|");
                    }
                    Console.WriteLine();
                }
            }
            else if (selection.Equals("P2"))
            {
                for (int x = 0; x < 10; x++)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        Console.Write(p2Board[x, i] + "|");
                    }
                    Console.WriteLine();
                }
            }
            else if (selection.Equals("P1Hit"))
            {
                for (int x = 0; x < 10; x++)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        Console.Write(p1Hit[x, i] + "|");
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                for (int x = 0; x < 10; x++)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        Console.Write(p2Hit[x, i] + "|");
                    }
                    Console.WriteLine();
                }
            }

        }
        static void helloPlayers()
        {
            Console.Title = "Battleship";
            Console.WriteLine("Welcome to Battleship.\n\nPress any key to continue");
            Console.ReadLine();

        }
        /*----------------------------------------------
         * this is validation for input when deploying and hitting the ships.  
         * there are 2 parameters. 
         * option is for choosing input circumstance. 
         * 1 is for regular validation while hitting the ships
         * 2 is validation of placing patrol ship during ship choicde at the beginning of the game
         * 3 is for placing destroyer and submarine ship
         * 4 is for placing battleship validation
         * 5 is for validation while placing air carrier. 
         * --------------------------------------------*/
        static bool inputValidation(string input, short option)
        {
            string pattern1 = @"^[A-J][0-9]$";
            string pattern2 = @"^[A-I][0-9]$";
            string pattern3 = @"^[A-H][0-9]$";
            string pattern4 = @"^[A-G][0-9]$";
            string pattern5 = @"^[A-F][0-9]$";

            bool flag = false;
            switch (option)
            {
                case 1:
                    flag = Regex.IsMatch(input, pattern1);
                    break;
                case 2:
                    flag = Regex.IsMatch(input, pattern2);
                    break;
                case 3:
                    flag = Regex.IsMatch(input, pattern3);
                    break;
                case 4:
                    flag = Regex.IsMatch(input, pattern4);
                    break;
                case 5:
                    flag = Regex.IsMatch(input, pattern5);
                    break;
            }

            return flag;

        }
    }
}

