﻿using System;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Security.Authentication;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using PWDTK_DOTNET451;
using System.Text.RegularExpressions;

namespace BattleShip
{
    public sealed class SslTcpServer
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private static List<User> loggedInUser;
        private static List<Game> games;
        private static int saltLengthLimit = 128;
        private static int saltIterations = 10000;
        private static X509Certificate serverCertificate = null;
        
        // The certificate parameter specifies the name of the file 
        // containing the machine certificate.
        public static void RunServer(string certificate)
        {
            AppDomain domain = AppDomain.CurrentDomain;
            // Set a timeout interval of 2 seconds.
            domain.SetData("REGEX_DEFAULT_MATCH_TIMEOUT", TimeSpan.FromSeconds(10));

            serverCertificate = X509Certificate.CreateFromCertFile(certificate);
            loggedInUser = new List<User>();
            games = new List<Game>();
            // Create a TCP/IP (IPv4) socket and listen for incoming connections.
            TcpListener listener = new TcpListener(IPAddress.Any, 7777);
            listener.Start();
            while (true)
            {
                Console.WriteLine("Waiting for a client to connect...");
                // Application blocks while waiting for an incoming connection.
                // Type CNTL-C to terminate the server.
                TcpClient client = listener.AcceptTcpClient();
                Task.Run(()=> ProcessClient(client));
                //ProcessClient(client);
            }
        }

        private static void ProcessClient(TcpClient client)
        {
            // A client has connected. Create the 
            // SslStream using the client's network stream.
            SslStream sslStream = new SslStream(
                client.GetStream(), false);
            // Authenticate the server but don't require the client to authenticate.
            try
            {
                sslStream.AuthenticateAsServer(serverCertificate,
                    false, SslProtocols.Tls, true);
                // Display the properties and settings for the authenticated stream.
                DisplaySecurityLevel(sslStream);
                DisplaySecurityServices(sslStream);
                DisplayCertificateInformation(sslStream);
                DisplayStreamProperties(sslStream);

                // Set timeouts for the read and write to 5 seconds.
                sslStream.ReadTimeout = 30000;
                //sslStream.WriteTimeout = 5000;

                bool isConnected = true;
                while (isConnected)
                {
                    // Read a message from the client.   
                    Console.WriteLine("Waiting for client message...");
                    string messageData = ReadMessage(sslStream);
                    Console.WriteLine("Received: {0}", messageData);

                    if (string.IsNullOrEmpty(messageData))
                    {
                        sslStream.Write(Encoding.UTF8.GetBytes("Error,Unknown error occurred.<EOF>"));
                        continue;
                    }
                    messageData = messageData.Substring(0, messageData.IndexOf("<EOF>"));
                    switch (messageData)
                    {
                        case "Register":
                            RegisterNewUser(sslStream);
                            break;
                        case "Login":
                            LoginUser(sslStream);
                            break;
                        case "Quit":
                        case "Timeout":
                            isConnected = false;
                            break;
                        default:
                            break;
                    }
                }

            }
            catch (AuthenticationException e)
            {
                log.Error(e.ToString());
                Console.WriteLine("Exception: {0}", e.Message);
                if (e.InnerException != null)
                {
                    Console.WriteLine("Inner exception: {0}", e.InnerException.Message);
                }
                Console.WriteLine("Authentication failed - closing the connection.");
                sslStream.Close();
                client.Close();
                return;
            }
            finally
            {
                // The client stream will be closed with the sslStream
                // because we specified this behavior when creating
                // the sslStream.
                sslStream.Close();
                client.Close();
            }
        }

        private static void LoginUser(SslStream sslStream)
        {
            string messageData = "";
            messageData = ReadMessage(sslStream);
            string username = messageData.Substring(0, messageData.IndexOf("<EOF>"));
            messageData = ReadMessage(sslStream);
            string password = messageData.Substring(0, messageData.IndexOf("<EOF>"));
            player p = validateUser(username, password);
            if (p != null)
            {
                if (loggedInUser.Where(x=>x.p.player_username.Equals(p.player_username)).FirstOrDefault() != null)
                {
                    sslStream.Write(Encoding.UTF8.GetBytes("Error,User already logged in.<EOF>"));
                }
                else
                {
                    sslStream.Write(Encoding.UTF8.GetBytes("Success,<EOF>"));
                    User u = new User(p, sslStream);
                    loggedInUser.Add(u);
                    joinOrStartMenu(u);
                }
            }
            else
                sslStream.Write(Encoding.UTF8.GetBytes("Error,Invalid username and/or password.<EOF>"));
        }

        private static string stats()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine();
            BlackshipEntities entities = new BlackshipEntities();
            List<player> allPlayer = entities.players.ToList();
            List<game> allGames = entities.games.ToList();
            foreach (var p in allPlayer)
            {
                List<game> pG = allGames.Where(x => x.player1_id == p.player_id || x.player2_id == p.player_id).ToList();
                sb.AppendLine("==================================================");
                sb.AppendLine("Stats for player: " + p.player_username);
                int draw = 0;
                int wins = 0;
                int loss = 0;
                for (int i = 0; i < pG.Count; i++)
                {
                    sb.AppendLine((i + 1) + "." + getPlayerUsernameById(pG[i].player1_id) + "\t against \t" + getPlayerUsernameById(pG[i].player2_id));
                    if (pG[i].draw == true)
                    {
                        sb.AppendLine("\tMatch drawn.");
                        draw++;
                    }
                    if (pG[i].player1win == true)
                    {
                        sb.AppendLine("\t" + getPlayerUsernameById(pG[i].player1_id) + " won the game.");
                        if (getPlayerUsernameById(pG[i].player1_id).Equals(p.player_username))
                            wins++;
                        else
                            loss++;
                    }
                    if (pG[i].player2win == true)
                    {
                        sb.AppendLine("\t" + getPlayerUsernameById(pG[i].player2_id) + " won the game.");
                        if (getPlayerUsernameById(pG[i].player2_id).Equals(p.player_username))
                            wins++;
                        else
                            loss++;
                    }
                    sb.AppendLine();
                }
                sb.AppendLine("Total Wins: " + wins);
                sb.AppendLine("Total Loss: " + loss);
                sb.AppendLine("Total Draw: " + draw);
                sb.AppendLine("==================================================");
            }
            sb.AppendLine();
            return sb.ToString();
        }

        private static string getPlayerUsernameById(long id)
        {
            var p = new BlackshipEntities().players.Where(x => x.player_id == id).FirstOrDefault();
            if (p == null) return string.Empty;
            return p.player_username;
        }

        private static void joinOrStartMenu(User u)
        {
            string messageData = "";
            bool isConnected = true;
            while (isConnected == true)
            {
                messageData = ReadMessage(u.sslStream);
                Console.WriteLine("Received: {0}", messageData);

                if (string.IsNullOrEmpty(messageData))
                {
                    u.sslStream.Write(Encoding.UTF8.GetBytes("Error,Unknown error occurred.<EOF>"));
                    continue;
                }
                messageData = messageData.Substring(0, messageData.IndexOf("<EOF>"));
                switch (messageData)
                {
                    case "New":
                        createNewGame(u);
                        break;
                    case "Join":
                        joinGame(u);
                        break;
                    case "Stats":
                        u.sslStream.Write(Encoding.UTF8.GetBytes("Info," + stats() + "<EOF>"));
                        break;
                    case "Logout":
                        loggedInUser.Remove(u);
                        isConnected = false;
                        break;
                    case "Timeout":
                        isConnected = false;
                        break;
                    default:
                        break;
                }
            }
        }

        private static void joinGame(User u)
        {
            Game g = games.Where(x => x.canJoin()).FirstOrDefault();
            if (g == null)
            {
                //Console.WriteLine("No games available to join.");
                u.sslStream.Write(Encoding.UTF8.GetBytes("Error,No games available to join.<EOF>"));
                return;
            }
            g.addPlayer(u);
            while (!g.isGameOver)
            {
                Thread.Sleep(1000);
            }
        }

        private static void createNewGame(User u)
        {
            Game g = new Game(u);
            games.Add(g);
            g.startGame();
            g.endGame();
            BlackshipEntities entities = new BlackshipEntities();
            entities.games.Add(new game {
                player1_id = u.p.player_id,
                player2_id = g.u2.p.player_id,
                draw = g.winner == 0,
                player1win = g.winner == 1,
                player2win = g.winner == 2
            });
            entities.SaveChanges();
        }

        private static player validateUser(string username, string password)
        {
            BlackshipEntities entities = new BlackshipEntities();
            player p;            
            if ( (p = entities.players.Where(x => x.player_username.Equals(username)).FirstOrDefault()) == null)
            {
                Console.WriteLine("Error: Invalid user.");
                return null;
            }
            if (ComparePasswords(p.player_salt, password, p.player_password, p.iteration_count)) return p;
            return null;
        }

        private static void RegisterNewUser(SslStream sslStream)
        {
            string messageData = "";
            messageData = ReadMessage(sslStream);
            string username = messageData.Substring(0, messageData.IndexOf("<EOF>"));
            messageData = ReadMessage(sslStream);
            string passwordHash = messageData.Substring(0, messageData.IndexOf("<EOF>"));
            bool result = registerNewAccount(username, passwordHash);
            if (result)
                sslStream.Write(Encoding.UTF8.GetBytes("Success,<EOF>"));
            else
                sslStream.Write(Encoding.UTF8.GetBytes("Error,Username already used.<EOF>"));
        }

        private static bool registerNewAccount(string username, string password)
        {
            BlackshipEntities entities = new BlackshipEntities();
            string salt = byteToString(GetSalt());

            if (entities.players.Where(x => x.player_username.Equals(username)).FirstOrDefault() != null)
            {
                Console.WriteLine("Error: Username already used.");
                return false;
            }
            string[] hashWithSalt = HashPassword(password, saltIterations).Split('|');
            
            entities.players.Add(new player
            {
                player_username = username,
                player_password = hashWithSalt[0],
                player_salt = hashWithSalt[1],
                iteration_count = saltIterations
            });
            entities.SaveChanges();
            return true;
        }

        private static byte[] GetSalt()
        {
            return GetSalt(saltLengthLimit);
        }

        private static byte[] GetSalt(int maximumSaltLength)
        {
            var salt = new byte[maximumSaltLength];
            using (var random = new RNGCryptoServiceProvider())
            {
                random.GetNonZeroBytes(salt);
            }

            return salt;
        }

        private static string byteToString(byte[] b)
        {
            StringBuilder hash = new StringBuilder();
            foreach (byte theByte in b)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }

        private static string ReadMessage(SslStream sslStream)
        {
            try
            {
                // Read the  message sent by the client.
                // The client signals the end of the message using the
                // "<EOF>" marker.
                byte[] buffer = new byte[2048];
                StringBuilder messageData = new StringBuilder();
                int bytes = -1;
                do
                {
                    // Read the client's test message.
                    bytes = sslStream.Read(buffer, 0, buffer.Length);

                    // Use Decoder class to convert from bytes to UTF8
                    // in case a character spans two buffers.
                    Decoder decoder = Encoding.UTF8.GetDecoder();
                    char[] chars = new char[decoder.GetCharCount(buffer, 0, bytes)];
                    decoder.GetChars(buffer, 0, bytes, chars, 0);
                    messageData.Append(chars);
                    // Check for EOF or an empty message.
                    if (messageData.ToString().IndexOf("<EOF>") != -1)
                    {
                        break;
                    }
                } while (bytes != 0);
                log.Info("Received: " + @messageData.ToString());
                return messageData.ToString();
            }
            catch (System.IO.IOException ex)
            {
                log.Error(ex.ToString());
                return "Timeout<EOF>";
            }
            
        }

        private static void DisplaySecurityLevel(SslStream stream)
        {
            Console.WriteLine("Cipher: {0} strength {1}", stream.CipherAlgorithm, stream.CipherStrength);
            Console.WriteLine("Hash: {0} strength {1}", stream.HashAlgorithm, stream.HashStrength);
            Console.WriteLine("Key exchange: {0} strength {1}", stream.KeyExchangeAlgorithm, stream.KeyExchangeStrength);
            Console.WriteLine("Protocol: {0}", stream.SslProtocol);
        }

        private static void DisplaySecurityServices(SslStream stream)
        {
            Console.WriteLine("Is authenticated: {0} as server? {1}", stream.IsAuthenticated, stream.IsServer);
            Console.WriteLine("IsSigned: {0}", stream.IsSigned);
            Console.WriteLine("Is Encrypted: {0}", stream.IsEncrypted);
        }

        private static void DisplayStreamProperties(SslStream stream)
        {
            Console.WriteLine("Can read: {0}, write {1}", stream.CanRead, stream.CanWrite);
            Console.WriteLine("Can timeout: {0}", stream.CanTimeout);
        }

        private static void DisplayCertificateInformation(SslStream stream)
        {
            Console.WriteLine("Certificate revocation list checked: {0}", stream.CheckCertRevocationStatus);

            X509Certificate localCertificate = stream.LocalCertificate;
            if (stream.LocalCertificate != null)
            {
                Console.WriteLine("Local cert was issued to {0} and is valid from {1} until {2}.",
                    localCertificate.Subject,
                    localCertificate.GetEffectiveDateString(),
                    localCertificate.GetExpirationDateString());
            }
            else
            {
                Console.WriteLine("Local certificate is null.");
            }
            // Display the properties of the client's certificate.
            X509Certificate remoteCertificate = stream.RemoteCertificate;
            if (stream.RemoteCertificate != null)
            {
                Console.WriteLine("Remote cert was issued to {0} and is valid from {1} until {2}.",
                    remoteCertificate.Subject,
                    remoteCertificate.GetEffectiveDateString(),
                    remoteCertificate.GetExpirationDateString());
            }
            else
            {
                Console.WriteLine("Remote certificate is null.");
            }
        }

        private static void DisplayUsage()
        {
            Console.WriteLine("To start the server specify:");
            Console.WriteLine("serverSync certificateFile.cer");
            Environment.Exit(1);
        }

        public static int Main(string[] args)
        {
            //Task.Run(() => System.Diagnostics.Process.Start(@"C:\Users\Amyn\Documents\visual studio 2012\Projects\BattleShip\BattleShipClient\bin\Debug\BattleShipClient.exe"));
            string certificate = null;
            if (args == null || args.Length < 1)
            {
                DisplayUsage();
            }
            certificate = args[0];
            SslTcpServer.RunServer(certificate);
            return 0;
        }

        private static string computeHash(string value)
        {
            System.Security.Cryptography.SHA256Managed crypt = new System.Security.Cryptography.SHA256Managed();
            System.Text.StringBuilder hash = new System.Text.StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(value), 0, Encoding.UTF8.GetByteCount(value));
            foreach (byte theByte in crypto)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }

        public static string HashPassword(string password, int iterations)
        {
            Byte[] _salt = PWDTK.GetRandomSalt(saltLengthLimit);
            Byte[] _hash = PWDTK.PasswordToHash(_salt, password, iterations);

            return Convert.ToBase64String(_hash) + "|" + Convert.ToBase64String(_salt);
        }

        private static bool ComparePasswords(string salt, string password, string hash, int iterations)
        {
            return PWDTK.ComparePasswordToHash(Convert.FromBase64String(salt), password, Convert.FromBase64String(hash), iterations);
        }

        private static bool validateUsername(string username)
        {
            string pattern = @"^[A-Za-z]{8,15}$";
            return Regex.IsMatch(username, pattern);
        }

        static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }
    }
}