﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BattleShip
{
    public class User
    {
        public player p { get; set; }
        public SslStream sslStream { get; set; }
        

        public User(player pl, SslStream s)
        {
            this.p = pl;
            this.sslStream = s;
        }
    }

    public class Game
    {
        private Battle battle;

        public User u1 { get; set; }
        public User u2 { get; set; }
        public bool isGameOver = false;
        public short winner { get; set; }
        public Game(User u)
        {
            u1 = u;
            u2 = null;
        }

        public void addPlayer(User u)
        {
            u2 = u;

        }

        public bool canJoin()
        {
            return u2 == null;
        }

        public void endGame()
        {
            try
            {
                u1.sslStream.Write(Encoding.UTF8.GetBytes("GameOver,<EOF>"));
            }
            catch(Exception ex)
            {

            }
            try
            {
                u2.sslStream.Write(Encoding.UTF8.GetBytes("GameOver,<EOF>"));
            }
            catch (Exception ex)
            {

            }
        }

        public void startGame()
        {
            u1.sslStream.Write(Encoding.UTF8.GetBytes("Info,New game created. Waiting for a player to join.<EOF>"));
            while (canJoin())
            {
                Thread.Sleep(5000);
                if (!player1Connected())
                {
                    Console.WriteLine("Client 1 has disconnected.");
                    return;
                }
            }
            if (player1Connected())
            {
                // Start a new game. both players have joined.
                u1.sslStream.Write(Encoding.UTF8.GetBytes("Begin,You will be playing against user: " + u2.p.player_username + ".<EOF>"));
                u2.sslStream.Write(Encoding.UTF8.GetBytes("Begin,You will be playing against user: " + u1.p.player_username + ".<EOF>"));

                battle = new Battle(u1, u2);

                battle.beginGame();

                winner = battle.winStatus;
            }
            isGameOver = true;
        }
        
        private bool player1Connected()
        {
            try
            {
                u1.sslStream.Write(new byte[0]);
            }
            catch (System.IO.IOException ex)
            {
                return false;
            }
            return true;
        }
    }
}
